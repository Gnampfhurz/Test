//Jahreiss, Kevin; Karasz, David; Urban, Melanie; 
import java.util.Random;
import java.util.UUID;

public class MyQueueDemo {

	public static void main (String[] args) {
		
		//Hier werden 4 Queues mit unterschiedlichen Objekten initialisiert
		MyQueue<Integer> a = new MyQueue<Integer>();		
		MyQueue<String> b = new MyQueue<String>();
		MyQueue<Day> c = new MyQueue<Day>();
		MyQueue<Double> d = new MyQueue<Double>();
		
		//Exemplarisch wird alles an der Day-Queue getestet; hier wird erstmal eine Day-Queue mit drei Objekten geschaffen, zus�tzlich wird dequeue getestet
		c.enqueue(new Day("regen", 15));
		c.enqueue(new Day("sonnig", 25));
		c.enqueue(new Day("nebelig", 10));
		System.out.println(c.toString());
		c.dequeue();
		System.out.println(c.toString());
		c.enqueue(new Day("bewoelkt", 17));
		System.out.println(c.toString());
		while(0 < c.size())
			c.dequeue();
		
		//Nun werden alle 4 Queues mit 1000 jeweils 1000 zuf�lligen Objekten gef�llt; hier werden wieder anhand der Day-Queue diverse Methoden getestet
		for(int i = 0; i < 1000; i++) {
			a.enqueue(new Random().nextInt(1000));
		}
		System.out.println(a.toString());
		
		for(int i = 0; i < 1000; i++) {
			b.enqueue(UUID.randomUUID().toString());
		}
		System.out.println(b.toString());
		
		System.out.println(c.size());
		System.out.println(c.isEmpty());
		System.out.println(c.peek());
		System.out.println(c.reversePeek());
		for(int i = 0; i < 1000; i++) {
			c.enqueue(new Day(weather(), new Random().nextInt(30) - new Random().nextInt(30)));
		}
		System.out.println(c.toString());
		System.out.println(c.size());
		System.out.println(c.isEmpty());
		System.out.println(c.peek());
		System.out.println(c.reversePeek());
		
		for(int i = 0; i < 1000; i ++) {
			d.enqueue(new Random().nextDouble() * 1000);
		}
		System.out.println(d.toString());
		
		//Hier werden wiederholt zuf�llige Methoden f�r jede Queue ausgef�hrt (man beachte, dass nur die Day-Queue nicht auskommentiert ist)
		/*for(int i = 0; i < 1000; i++) {
			int n = new Random().nextInt(4);
			if(n == 0) { 
				System.out.println("Ein Element wurde entfernt: " + a.dequeue());
			}
			if(n == 1) {
				a.enqueue(new Random().nextInt(1000));
				System.out.println("Ein Element wurde hinzugef�gt.");
			}
			if(n == 2) {
				System.out.println("Gr��e wird abgefragt: " + a.size());
			}
			if(n == 3) {
				System.out.println("Erstes Element wird angeschaut: " + a.peek());
			}
		}*/
		
		/*for(int i = 0; i < 1000; i++) {
			int n = new Random().nextInt(4);
			if(n == 0) { 
				System.out.println("Ein Element wurde entfernt: " + b.dequeue());
			}
			if(n == 1) {
				b.enqueue(UUID.randomUUID().toString());
				System.out.println("Ein Element wurde hinzugef�gt.");
			}
			if(n == 2) {
				System.out.println("Gr��e wird abgefragt: " + b.size());
			}
			if(n == 3) {
				System.out.println("Erstes Element wird angeschaut: " + b.peek());
			}
		}*/
		
		for(int i = 0; i < 1000; i++) {
			int n = new Random().nextInt(4);
			if(n == 0) { 
				System.out.println("Ein Element wurde entfernt: " + c.dequeue());
			}
			if(n == 1) {
				c.enqueue(new Day(weather(), new Random().nextInt(30) - new Random().nextInt(30)));
				System.out.println("Ein Element wurde hinzugef�gt: " + c.reversePeek());
			}
			if(n == 2) {
				System.out.println("Gr��e wird abgefragt: " + c.size());
			}
			if(n == 3) {
				System.out.println("Erstes Element wird angeschaut: " + c.peek());
			}
		}
		
		/*for(int i = 0; i < 1000; i++) {
			int n = new Random().nextInt(4);
			if(n == 0) { 
				System.out.println("Ein Element wurde entfernt: " + d.dequeue());
			}
			if(n == 1) {
				d.enqueue(new Random().nextDouble() * 1000);
				System.out.println("Ein Element wurde hinzugef�gt.");
			}
			if(n == 2) {
				System.out.println("Gr��e wird abgefragt: " + d.size());
			}
			if(n == 3) {
				System.out.println("Erstes Element wird angeschaut: " + d.peek());
			}
		}*/
	}
	
	
	//Hilfsmethode f�r die Generierung eines zuf�lligen Wettertyps
	public static String weather() {
		int n = new Random().nextInt(4);
		String str = "";
		switch(n) {
		case 0:
			str = "sonnig";
			break;
		case 1:
			str = "regnerisch";
			break;
		case 2:
			str = "nebelig";
			break;
		case 3:
			str = "bewoelkt";
			break;
		default:
			str = "anderes";
		}
		return str;
	}
}
