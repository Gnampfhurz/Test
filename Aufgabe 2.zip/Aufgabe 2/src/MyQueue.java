//Jahreiss, Kevin; Karasz, David; Urban, Melanie; 
import java.util.ArrayList;

public class MyQueue<T> {

	private ArrayList<T> list = new ArrayList<T>();
	
	//Alle Methoden bis auf toString() sollten selbsterkl�rend sein
	public MyQueue() {
	}

	public void enqueue(T item) {
		list.add(item);
	}

	public T dequeue() {
		if (list.size() > 0) {
			T a;
			a = list.get(0);
			list.remove(0);
			return a;
		} else
			return null;
	}

	public T peek() {
		if (list.size() > 0)
			return list.get(0);
		else
			return null;
	}
	//reversePeek() wurde au�erhalb der Aufgabenstellung eingef�gt, um eine gew�nschte Ausgabe zu erzeugen
	public T reversePeek() {
		if (list.size() > 0)
			return list.get(list.size() - 1);
		else
			return null;
	}

	public boolean isEmpty() {
		if (list.size() == 0)
			return true;
		return false;
	}

	public int size() {
		return list.size();
	}

	public String toString() {
		String a = "[";
		String b = "(";
		//Als erstes wird die Ausgabe "(e01, e02, ....)" erzeugt
		if (list.size() == 0)	
			return "Die Warteschlange ist leer";
		for (int i = 0; i < list.size() - 1; i++) {
			if (i == 0) {
				b = b + list.get(i);
			} else {
				b = b.substring(0, b.length()) + ", " + list.get(i);
			}
		}
		//Die if-Abfrage ist an dieser Stelle sinnvoll, da toString(), wenn nur ein Element in der Queue ist, direkt hinter "(" ein ", " erzeugt
		if (list.size() != 1) {
			b = b + ", " + list.get(list.size() - 1) + " are the elements of the queue): ";
		} else {
			b = b + list.get(0) + " are the elements of the queue): ";
		}
		//Als zweites wird die Ausgabe "[e01, e02, ...]" erzeugt
		for (int i = 0; i < list.size() - 1; i++) {
			if (i == 0) {
				a = a + list.get(i);
			} else {
				a = a.substring(0, a.length()) + ", " + list.get(i);
			}
		}
		//Selbe if-Abfrage wie bei b
		if (list.size() != 1) {
			a = list.get(0).getClass() + b + a + ", " + list.get(list.size() - 1) + "]";			//die getClass() Methode dient dazu den Typ der Queue zu bestimmen
			a = a.substring(a.indexOf(".") + 1);													//da getClass() nicht nur den Namen der Typen zur�ckgibt, werden hier alle unn�tigen Textfragmente entfernt
			a = a.substring(a.indexOf(".") + 1);													//das Entfernen mit lastIndexOf() funktioniert bei Objekten, die "." (z.B. doubles) nicht, deshalb wird der Befehl zweimal ausgef�hrt
			a = a.substring(0, a.indexOf("(")) + " " + a.substring(a.indexOf("("));
		} else {
			a = list.get(0).getClass() + b + a + list.get(0) + "]";
			a = a.substring(a.indexOf(".") + 1);
			a = a.substring(a.indexOf(".") + 1);
			a = a.substring(0, a.indexOf("(")) + " " + a.substring(a.indexOf("("));
		}
		return a;
	}
}
